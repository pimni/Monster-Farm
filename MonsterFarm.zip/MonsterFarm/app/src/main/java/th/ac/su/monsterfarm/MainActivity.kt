package th.ac.su.monsterfarm

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import com.google.gson.Gson
import th.ac.su.monsterfarm.Utils.getJsonDataFromAsset
import th.ac.su.monsterfarm.data.Monster

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val jsonFlieString = getJsonDataFromAsset(applicationContext,"monster_data.json")

        Log.i("data",jsonFlieString!!)
        val gson = Gson()
    }
}